window.setTimeout(() => {
    AOS.init();
}, 500)
window.setTimeout(() => {
    $('body').removeClass('overflow-hidden');
}, 1000)